Oracle WebLogic SmartUpgrade - Release 11.1.1.3.0 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Oracle WebLogic SmartUpgrade download package contains both command line upgrade 
tool and the JDeveoper extensions. The comand line upgrade tool is packaged as
smartupgrade.zip; and the JDeveloper extensions are packaged as jdeveloper_smartupgrade.zip.

Each zip file includes a readme.txt which gives the details of how to install 
and use the upgrade tool through its respective interface.
