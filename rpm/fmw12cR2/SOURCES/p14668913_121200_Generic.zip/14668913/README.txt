===============================
Interim Patch for Bug: 14668913
===============================

-------------------
Oracle Confidential
-------------------

Date:  Sep 25, 2013
----------------------------------
Platform Patch for      : Generic
Product Patched         : Oracle WebLogic Server
Product Version         : 12.1.2.0.0


Bugs Fixed by this patch:
-------------------------
14668913- NODEMANAGER PRESENTING WRONG CERT CHAIN

Prerequisites:
--------------

1. Before applying non-mandatory patches, check whether you have the exact symptoms
   described in the bug.

2. Review that the OPatch version is 13.1 or higher

3. Verify the OUI Inventory.

   OPatch needs access to a valid OUI inventory to apply patches.
   Validate the OUI inventory with the following command:
   - opatch lsinventory -jdk $JAVA_HOME   (in Windows %JAVA_HOME%)

   If the command errors out, contact Oracle Support and work to validate
   and verify the inventory setup before proceeding.

4. Confirm executables appear in your system PATH.

   The patching process will use the unzip and the opatch executables. After
   setting the ORACLE_HOME environment, confirm both of these exist before
   continuing:

   - "which opatch"
   - "which unzip"

   If either of these executables do not show in the PATH, correct the problem
   before proceeding.

5. Create a location for storing the unzipped patch. This location
   will be referred to later in the document as PATCH_TOP.



Pre Install Instructions:
-------------------------

- Stop all Webogic Server instances (AdminServer and all Managed server(s))


Install Instructions:
---------------------

1. Unzip the patch zip file into the PATCH_TOP.

   unzip -d PATCH_TOP p14668913_121200_Generic.zip
   
   NOTE. p14668913_121200_Generic.zip cannot be in PATCH_TOP directory.

2. Set your current directory to the directory where the patch is located.

   cd PATCH_TOP/14668913

3. Run OPatch to apply the patch.

   Run following command:
   - opatch apply -jdk $JAVA_HOME   (in Windows %JAVA_HOME%)


When OPatch starts, it will validate the patch and make sure there
are no conflicts with the software already installed in the ORACLE_HOME.
OPatch categorizes two types of conflicts:

  (a) Conflicts with a patch already applied to the ORACLE_HOME
  In this case, please stop the patch installation and contact
  Oracle Support Services.

  (b) Conflicts with subset patch already applied to the ORACLE_HOME
  In this case, please continue the install, as the new patch
  contains all the fixes from the existing patch in the ORACLE_HOME.
  The subset patch will automatically be rolled back prior to the
  installation of the new patch.

4. Run OPatch to verify the patch application.

   Run following command:
   - opatch lsinventory -jdk $JAVA_HOME   (in Windows %JAVA_HOME%)


Post Install Instructions:
--------------------------

- Start all servers (AdminServer and all Managed server(s))



Deinstallation Instructions:
----------------------------

If you experience any problems after installing this patch, remove the patch as follows:

1. Make sure to follow the same Prerequisites or pre-install steps (if any) when deinstalling a patch.
   This includes setting up any environment variables like ORACLE_HOME and verifying the OUI inventory
   before deinstalling.

2. Change to the directory where the patch was unzipped.
   cd PATCH_TOP/14668913

3. Run OPatch to deinstall the patch.

   Run following command:
   - opatch rollback -id 14668913 -jdk $JAVA_HOME   (in Windows %JAVA_HOME%)




DISCLAIMER:
===========
This interim patch has undergone only basic unit testing. It has not been through the complete
test cycle that is generally followed for a production patch set. Though the fix in this interim
patch rectifies the bug, Oracle Corporation will not be responsible for other issues that may arise
due to this fix. Oracle Corporation recommends that you upgrade to the next production patch set,
when it is available. Applying this interim patch could overwrite other interim patches applied
since the last patch set. Customers need to request Oracle Support for a patch that includes those
fixes as well as inform Oracle Support about all the PSE installed when an SR is opened.
Please download, test, and provide feedback as soon as possible to assist in the timely resolution
of this problem.
