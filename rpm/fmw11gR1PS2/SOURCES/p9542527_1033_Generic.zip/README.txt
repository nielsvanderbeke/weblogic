Content:
========
This patch contains Smart Update patch H6DH for WebLogic Server 10.3.3.0

Description:
============
WLS THROWS EXCEPTIONS WHEN USING JSF 2.0 EXTENSIONS

Patch Installation Instructions:
================================
- copy content of this zip file with the exception of README file to your SmartUpdate cache directory (MW_HOME/utils/bsu/cache_dir by default)
- apply patch using Smart Update utility