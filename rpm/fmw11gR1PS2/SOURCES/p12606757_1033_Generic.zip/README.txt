Content:
========
This patch contains Smart Update patch HTGX for WebLogic Server 10.3.3.0

Description:
============
JMS MESSAGE BRIDGE ALWAYS SHOWS STATUS AS ACTIVE EVEN WHEN IT IS STOPPED

Patch Installation Instructions:
================================
- copy content of this zip file with the exception of README file to your SmartUpdate cache directory (MW_HOME/utils/bsu/cache_dir by default)
- apply patch using Smart Update utility