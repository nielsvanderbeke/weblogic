Content:
========
This patch contains Smart Update patch SQYW for WebLogic Server 10.3.3.0

Description:
============
[MENTORING] - SERVERS LOOSING THE CLUSTERABLEREMOTEREF LIST FROM THE JNDI OBJECT

Patch Installation Instructions:
================================
- copy content of this zip file with the exception of README file to your SmartUpdate cache directory (MW_HOME/utils/bsu/cache_dir by default)
- apply patch using Smart Update utility